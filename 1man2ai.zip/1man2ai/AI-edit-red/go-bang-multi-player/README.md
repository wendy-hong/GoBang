# GoBang
基于PyQt5的五子棋编程（双人对弈）



#### 运行环境

python3.6

PyQt5



#### 运行方法：

1. 运行server.py
2. 运行client.py并输入server的ip
3. 选择持方后开始游戏

#### 

#### Tips：

运行方法请在Canvas里查看视频

目前不支持重新开始游戏，需要同学们自行填写

本程序在Ubuntu下完成编程，在Windows下可能会出现问题，有问题请在Canvas平台中反馈